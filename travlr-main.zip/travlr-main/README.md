Architecture
•	Compare and contrast the types of frontend development you used in your full stack project, including Express HTML, JavaScript, and the single-page application (SPA). 
We started the process by extracting data from the html pages and storing them in JSON files.  Using this technique, it allowed the html page size reduced and handlebars now populate the data.  As for the static JSON files that were imported into the database MongoDB. Angular was used to create the application providing a single page due to the separate file so once the user selects the required data the SPA request the data from the database. 
•	Why did the backend use a NoSQL MongoDB database?
The backend used MongoDB due to its flexibility. The application requirements didn’t need several tables or statements to view data. MongoDB stores data as documents and doesn’t require traditional structures like other databases. 
Functionality
•	How is JSON different from Javascript and how does JSON tie together the frontend and backend development pieces? JSON is a data format that transfers between systems. JavaScript is a programming language used for applications.
•	Provide instances in the full stack process when you refactored code to improve functionality and efficiencies and name the benefits that come from reusable user interface (UI) components. Several times during the full stack process cause for refactoring code to improve functionality and efficiency. The main step where I noticed a lot of updating on a code was when we were updating the view of the add trips.  We updated the format and several modules once the button was created to ensure everything was connected so there would be functionality with the button. We also needed to update the format, so user interface is appeasing.
Testing
•	Methods for request and retrieval necessitate various types of API testing of endpoints, in addition to the difficulties of testing with added layers of security. Explain your understanding of methods, endpoints, and security in a full stack application. 
Endpoint is a URL that the Api interacts with the client to map a resource or functionality.  Security protects data and maintains integrity. This is done by authentication, authorization, encryption, and validation input. 

Reflection
•	How has this course helped you in reaching your professional goals? What skills have you learned, developed, or mastered in this course to help you become a more marketable candidate in your career field?  This course has helped me with perseverance. Although this course was extremely challenging, I had the opportunity to gain more knowledge in tools that I have been learning in my education journey.  My project may not have come out perfect, but I have a better understanding of how to build a website and all the steps to make it a functional website.  I will continue to practice the skills I learned in this class as it will help me grow further in the tech field 

