/* GET  travel view */
const travel = (req, rest) => {
    res.render('travel', { title: 'Travlr Getaways' });
};

module.exports = {
    travel
};